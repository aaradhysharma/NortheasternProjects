--Q.1
select sum("Total") as "Total sales $ via Invoice"  from "Invoice";
--Q.2
select Sum("Quantity"*"UnitPrice") as "Total sales $ via Invoiceline"  from "InvoiceLine";
--Q.3
select count("TrackId") as "Total tracks (songs) sold" from "Track";
--Q.4
select "BillingCountry",SUM("Total") as "Total sales $ by customer�s country" from "Invoice"
group by "BillingCountry" order by "Total sales $ by customer�s country" desc
--Q.5
select "BillingCountry","BillingState","BillingCity",SUM("Total") as "Total sales $ by customer�s geo" from "Invoice"
group by "BillingCountry","BillingState","BillingCity" order by "Total sales $ by customer�s geo" desc
--Q.6
select "FirstName", "LastName",sum("Total") as "TotalSales"
from "Customer"
inner join "Invoice" "I"
on "I"."CustomerId" ="Customer"."CustomerId"
group by "FirstName" , "LastName"  order by Sum("Total") desc

--Q.7
select "Company", Sum("Total") as "TotalSales"
from "Customer"
inner join "Invoice" "I"
on "I"."CustomerId" ="Customer"."CustomerId"
group by "Company"
order by Sum("Total") desc

--8)select ar.Name, sum(t.UnitPrice)
select "Artist"."Name", sum("Track"."UnitPrice")
from "Track" inner join "Album" on "Track"."AlbumId" = "Album"."AlbumId"
inner join "Artist"  on "Album"."ArtistId" = "Artist"."ArtistId"
group by "Artist"."Name"
order by sum("Track"."UnitPrice") desc

--9
select "Album"."AlbumId", "Album"."Title", sum("Track"."UnitPrice") as albumsale
from "Track" inner join "Album" on "Track"."AlbumId" = "Album"."AlbumId"
group by "Album"."AlbumId" , "Album"."Title"
order by sum("Track"."UnitPrice") desc

--10
select "EmployeeId",concat("LastName","FirstName") as "FullName",sum("Total")as "employeesale"
from "Employee" "e" 
inner join "Invoice" "Inv" on "e"."Country" = "Inv"."BillingCountry"
group by "BillingCountry","EmployeeId",concat("LastName","FirstName")
order by Sum("Total") desc


--11
select "m"."MediaTypeId", "m"."Name",sum("t"."UnitPrice")
from "MediaType" "m"
inner join "Track" "t"
on "t"."MediaTypeId" = "m"."MediaTypeId"
group by "m"."MediaTypeId" 
order by sum("t"."UnitPrice") desc



--12
select "Genre"."GenreId",sum("Track"."UnitPrice") 
from "Genre" 
inner join "Track"
on "Track"."GenreId" = "Genre"."GenreId"
group by "Genre"."GenreId"
order by sum("Track"."UnitPrice") desc




--13
SELECT extract( year from "InvoiceDate")  from "Invoice"
