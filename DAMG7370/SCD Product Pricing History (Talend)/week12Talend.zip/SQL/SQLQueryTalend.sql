/****** Script for Dileveribles command from SSMS  ******/
--Q1
SELECT count(*) as AllProducts
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD];

--Q2
select count(distinct [ProductID]) as UniqueProducts
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD];

--Q3
with dpl  as( SELECT
    ProductID, COUNT(*) as x
FROM
    [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]
GROUP BY
    ProductID
HAVING 
    COUNT(*) > 1
)select count (*) as multiplePrice from dpl;

--4
SELECT [ProductName]
      ,[ListPrice]
      ,[scd_start] as LatestDate
      ,[scd_version] as versions
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]
WHERE [scd_active]=1;

--5
select[ProductName]
      ,[ListPrice]
      ,[scd_start] as LatestDate
      ,[scd_version] as versions
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]
WHERE ListPrice = (SELECT max(listprice) FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]);

--6
SELECT[ProductName]
      ,[ListPrice]
      ,[scd_start] as LatestDate
      ,[scd_version] as versions
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]
WHERE ListPrice = (SELECT min(listprice) FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]);

--7
SELECT[ProductName]
      ,[ListPrice]
      ,[scd_start] as LatestDate
      ,[scd_version] as versions
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]
WHERE ProductName = 'HL Road Frame - Red, 62';

--8
SELECT  count(distinct(productid)) as change2020
FROM [AdventureWorks2019].[dbo].[ProductPriceHistorySCD]
where scd_version > 1 and year(scd_start) =2020;