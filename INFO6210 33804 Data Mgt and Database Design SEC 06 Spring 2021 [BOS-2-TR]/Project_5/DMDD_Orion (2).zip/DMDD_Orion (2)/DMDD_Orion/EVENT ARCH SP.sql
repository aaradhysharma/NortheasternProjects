--------------------------------------------------------
--  File created - Thursday-April-29-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure EVENT_ARCH
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADMIN"."EVENT_ARCH" 
AS 
TODAY DATE;
BEGIN
SELECT SYSDATE INTO TODAY FROM DUAL;
FOR EVT IN (


    SELECT EVT_DATETIME, EVT_ID FROM EVENT  
)
LOOP
IF(EVT.EVT_DATETIME > TODAY)
THEN
    UPDATE EVENT SET EVT_STATUS=(SELECT EVT_STATUS_ID FROM EVENT_STATUS WHERE UPPER(EVT_STATUS)=UPPER('Archived'))
    WHERE EVT_ID=EVT.EVT_ID;
    COMMIT;
    END IF;

END LOOP;
 
END;

/

  GRANT EXECUTE ON "ADMIN"."EVENT_ARCH" TO "ORION_ADMIN";
