--------------------------------------------------------
--  File created - Thursday-April-29-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Trigger EVENTS_AFTER_DELETE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "ADMIN"."EVENTS_AFTER_DELETE" 
AFTER DELETE
    ON EVENT_REGISTRATION
    FOR EACH ROW
    
    DECLARE
    
    M_ID NUMBER(10);

    BEGIN

   SELECT MEMBER_ID INTO M_ID FROM MEMBERS WHERE UPPER(USERNAME) =UPPER((SELECT USER FROM DUAL));

   UPDATE EVENT SET EVT_STATUS=(SELECT EVT_STATUS_ID FROM EVENT_STATUS WHERE UPPER(EVT_STATUS)=UPPER('Registration Open'))
   WHERE EVT_ID=:OLD.EVT_ID;

   END;


/
ALTER TRIGGER "ADMIN"."EVENTS_AFTER_DELETE" ENABLE;
