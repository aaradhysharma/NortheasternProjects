--------------------------------------------------------
--  File created - Thursday-April-29-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure EVENT_DEREGISTER
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADMIN"."EVENT_DEREGISTER" (EVENT_NAME IN VARCHAR2)
AS
E_ID NUMBER(10);
STAT NUMBER(10);
M_ID NUMBER(10);
R_EXISTS NUMBER(10);
n_Count NUMBER(10);
err NUMBER(2);
BEGIN

ERR :=1;
SELECT EVT_ID INTO E_ID FROM EVENT WHERE UPPER(EVT_NAME) = UPPER(EVENT_NAME);

SELECT MEMBER_ID INTO M_ID FROM MEMBERS WHERE UPPER(USERNAME) =UPPER((SELECT USER FROM DUAL));


--check if registration exists
SELECT COUNT(*) INTO R_EXISTS FROM EVENT_REGISTRATION WHERE MEMBER_ID=M_ID AND EVT_ID=E_ID;

IF(R_EXISTS = 0) THEN

    dbms_output.put_line('User not registered for the event ' || EVENT_NAME);

ELSE

    DELETE FROM EVENT_REGISTRATION WHERE MEMBER_ID=M_ID AND EVT_ID=E_ID;

END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
    IF err=1 THEN
        DBMS_OUTPUT.PUT_LINE('INVALID EVENT NAME');
    END IF;

END;

/

  GRANT EXECUTE ON "ADMIN"."EVENT_DEREGISTER" TO "SAVANA5002";
